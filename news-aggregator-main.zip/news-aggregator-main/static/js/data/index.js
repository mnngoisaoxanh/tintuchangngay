window.availableDates = [
  "2025-08-09"
];