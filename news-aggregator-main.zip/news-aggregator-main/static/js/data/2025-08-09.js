window.newsData_2025_08_09 = {
  "date": "2025-08-09",
  "lastUpdated": "2025-08-09T09:26:55.408583+07:00",
  "articles": [
    {
      "id": "82fbb2334a9317e2639f234fe2a0115d",
      "title": "Nhiều tuyến đường tại Đà Nẵng biến thành 'bãi đậu xe'",
      "link": "https://tuoitre.vn/nhieu-tuyen-duong-tai-da-nang-bien-thanh-bai-dau-xe-20250808222406149.htm",
      "summary": "Nhiều tuyến đường tại Đà Nẵng dần biến thành “bãi đậu xe”, khiến việc đi lại hằng ngày của người dân gặp không ít khó khăn và tiềm ẩn nguy cơ xảy ra tai nạn.",
      "source": "Tuổi Trẻ",
      "category": "Tổng hợp",
      "published": "2025-08-09T09:26:47.201120+07:00",
      "fetched": "2025-08-09T09:26:47.201231+07:00"
    },
    {
      "id": "9d1ffee9cd83343c0ac49334eadd5a72",
      "title": "Nhạc sĩ 'Cho vừa lòng em’ qua đời",
      "link": "https://tuoitre.vn/nhac-si-cho-vua-long-em-qua-doi-20250808232613291.htm",
      "summary": "Nhạc sĩ Mặc Thế Nhân - chủ nhân ca khúc Cho vừa lòng em - qua đời ngày 8-8.",
      "source": "Tuổi Trẻ",
      "category": "Tổng hợp",
      "published": "2025-08-09T09:26:47.200999+07:00",
      "fetched": "2025-08-09T09:26:47.201109+07:00"
    },
    {
      "id": "a9d561b3181dbded9ded4d91bb17b02a",
      "title": "Suối Tiên: Từ trại nuôi trăn đến biểu tượng du lịch văn hóa Việt",
      "link": "https://tuoitre.vn/suoi-tien-tu-trai-nuoi-tran-den-bieu-tuong-du-lich-van-hoa-viet-20250805105557366.htm",
      "summary": "Từ một lâm trại nuôi trăn chỉ 6.600m², sau 30 năm phát triển, Suối Tiên với quy mô hơn 105ha đã trở thành biểu tượng giải trí văn hóa Việt Nam.",
      "source": "Tuổi Trẻ",
      "category": "Tổng hợp",
      "published": "2025-08-09T09:26:47.200876+07:00",
      "fetched": "2025-08-09T09:26:47.200988+07:00"
    },
    {
      "id": "64d1f0b2b280c6987518d970b13602f0",
      "title": "Điểm tin 8h: Tiến độ mở rộng sân bay Phú Quốc ra sao?Apple 'Mỹ hóa', Đông Nam Á gặp khó",
      "link": "https://tuoitre.vn/diem-tin-8h-tien-do-mo-rong-san-bay-phu-quoc-ra-sao-apple-my-hoa-dong-nam-a-gap-kho-20250809004410272.htm",
      "summary": "Nhiều thông tin được cập nhật trong chương trình \"Điểm tin cùng bạn 8h\" hôm nay, ngày 9-8-2025",
      "source": "Tuổi Trẻ",
      "category": "Tổng hợp",
      "published": "2025-08-09T09:26:47.200750+07:00",
      "fetched": "2025-08-09T09:26:47.200865+07:00"
    },
    {
      "id": "c55e1e6dade0ab7ae1250d918c1d5c31",
      "title": "Bán vé vào casino có ngăn được người nghiện cờ bạc?",
      "link": "https://tuoitre.vn/ban-ve-vao-casino-co-ngan-duoc-nguoi-nghien-co-bac-20250808231746614.htm",
      "summary": "Nếu thừa nhận người Việt cũng có nhu cầu giải trí thì cần tạo một môi trường minh bạch, có kiểm soát và có cơ chế hỗ trợ kịp thời.",
      "source": "Tuổi Trẻ",
      "category": "Tổng hợp",
      "published": "2025-08-09T09:26:47.200619+07:00",
      "fetched": "2025-08-09T09:26:47.200739+07:00"
    },
    {
      "id": "15db06c938369f8967f8fdc6d1246469",
      "title": "Hai nhà văn lọt top 100 nữ tỉ phú tự thân giàu nhất nước Mỹ năm 2025",
      "link": "https://tuoitre.vn/hai-nha-van-lot-top-100-nu-ti-phu-tu-than-giau-nhat-nuoc-my-nam-2025-20250807142727795.htm",
      "summary": "Tạp chí Forbes vừa công bố danh sách 100 nữ tỉ phú tự thân giàu nhất nước Mỹ năm 2025. Danielle Steel và Nora Roberts là hai nhà văn lọt top năm nay ở vị trí 67 và 71 với khối tài sản khổng lồ là 520 và 510 triệu USD.",
      "source": "Tuổi Trẻ",
      "category": "Tổng hợp",
      "published": "2025-08-09T09:26:47.200474+07:00",
      "fetched": "2025-08-09T09:26:47.200606+07:00"
    },
    {
      "id": "a8ff7ef5f5d07e4f73a85304f5a123a9",
      "title": "Tuyển nữ Indonesia tụt hạng thê thảm trước trận đấu Việt Nam",
      "link": "https://tuoitre.vn/tuyen-nu-indonesia-tut-hang-the-tham-truoc-tran-dau-viet-nam-20250809082012011.htm",
      "summary": "Trước trận đối đầu Việt Nam tại Giải bóng đá nữ Đông Nam Á 2025, tuyển nữ Indonesia đã rớt hạng thê thảm trên bảng xếp hạng FIFA.",
      "source": "Tuổi Trẻ",
      "category": "Tổng hợp",
      "published": "2025-08-09T09:26:47.200350+07:00",
      "fetched": "2025-08-09T09:26:47.200463+07:00"
    },
    {
      "id": "fe1f017ca2295a7b3bd67629b40732b2",
      "title": "Tây Ninh sẵn sàng bứt phá với công nghiệp xanh",
      "link": "https://tuoitre.vn/tay-ninh-san-sang-but-pha-voi-cong-nghiep-xanh-20250809080625568.htm",
      "summary": "Với vị trí địa lý chiến lược quan trọng trong vùng động lực Đông Nam Bộ và kết nối trực tiếp với vùng Tây Nam Bộ, Tây Ninh đang từng bước trở thành một trong những tỉnh phát triển mạnh mẽ trong vùng kinh tế trọng điểm phía Nam.",
      "source": "Tuổi Trẻ",
      "category": "Tổng hợp",
      "published": "2025-08-09T09:26:47.200222+07:00",
      "fetched": "2025-08-09T09:26:47.200339+07:00"
    },
    {
      "id": "14fe5724a543a38297ce3d942e0ddaf7",
      "title": "Nghi phạm xả súng làm 4 người chết ở bar Con Cú bị bắt sau 1 tuần truy lùng",
      "link": "https://tuoitre.vn/nghi-pham-xa-sung-lam-4-nguoi-chet-o-bar-con-cu-bi-bat-sau-1-tuan-truy-lung-20250809081835337.htm",
      "summary": "Nghi phạm Michael Paul Brown, 45 tuổi, đã bị bắt giữ sau một tuần truy lùng quy mô lớn.",
      "source": "Tuổi Trẻ",
      "category": "Tổng hợp",
      "published": "2025-08-09T09:26:47.200089+07:00",
      "fetched": "2025-08-09T09:26:47.200210+07:00"
    },
    {
      "id": "2c98d17b0a5a71edd08b276a81b68758",
      "title": "Số phận của The Batman, Superman và tương lai của DC",
      "link": "https://tuoitre.vn/so-phan-cua-the-batman-superman-va-tuong-lai-cua-dc-20250808072057529.htm",
      "summary": "Sau thời gian dài chờ đợi, tiến độ sản xuất của The Batman 2 và những phim tiếp theo thuộc tuyến truyện của Superman đã được Warner Bros. Discovery cập nhật cho khán giả.",
      "source": "Tuổi Trẻ",
      "category": "Tổng hợp",
      "published": "2025-08-09T09:26:47.199960+07:00",
      "fetched": "2025-08-09T09:26:47.200077+07:00"
    },
    {
      "id": "7e8986d0eda5b656f781d9d677346969",
      "title": "Sau 3 năm bị Ronaldo chê lỗi thời, trung tâm huấn luyện của Man United lột xác",
      "link": "https://tuoitre.vn/sau-3-nam-bi-ronaldo-che-loi-thoi-trung-tam-huan-luyen-cua-man-united-lot-xac-20250809082258963.htm",
      "summary": "Sau lời chê bai của Ronaldo cách đây 3 năm, giờ đây trung tâm huấn luyện của Man United đã được \"lột xác\" hoàn toàn, biến từ một cơ sở cũ kỹ thành một công trình hiện đại bậc nhất.",
      "source": "Tuổi Trẻ",
      "category": "Tổng hợp",
      "published": "2025-08-09T09:26:47.199829+07:00",
      "fetched": "2025-08-09T09:26:47.199948+07:00"
    },
    {
      "id": "b618c0db80d7cb2747bf46ce225b43ee",
      "title": "Universal cảnh báo kiện nếu ai tự ý dùng phim huấn luyện trí tuệ nhân tạo AI",
      "link": "https://tuoitre.vn/universal-canh-bao-kien-neu-ai-tu-y-dung-phim-huan-luyen-tri-tue-nhan-tao-ai-20250808233344284.htm",
      "summary": "Universal Pictures đang nỗ lực tăng cường chống lại việc sử dụng trái phép tác phẩm để huấn luyện AI bằng cách thêm cảnh báo mới vào phần credit cuối các phim phát hành gần đây.",
      "source": "Tuổi Trẻ",
      "category": "Tổng hợp",
      "published": "2025-08-09T09:26:47.199698+07:00",
      "fetched": "2025-08-09T09:26:47.199818+07:00"
    },
    {
      "id": "e5147cc213849770a5f192cdc62c4d6b",
      "title": "NASA phát hiện 'san hô' trên sao Hỏa",
      "link": "https://tuoitre.vn/nasa-phat-hien-san-ho-tren-sao-hoa-2025080816181987.htm",
      "summary": "NASA vừa công bố loạt hình ảnh thú vị do tàu thám hiểm Curiosity gửi về, trong đó có một tảng đá nhỏ trên sao Hỏa trông giống hệt một nhánh san hô dưới đáy biển Trái đất.",
      "source": "Tuổi Trẻ",
      "category": "Tổng hợp",
      "published": "2025-08-09T09:26:47.199559+07:00",
      "fetched": "2025-08-09T09:26:47.199685+07:00"
    },
    {
      "id": "15eea9362303d71169b61a438650b143",
      "title": "Bẻ cành cây trên bán đảo Sơn Trà - Đà Nẵng, một người đàn ông bị phạt 1,25 triệu đồng",
      "link": "https://tuoitre.vn/be-canh-cay-tren-ban-dao-son-tra-da-nang-mot-nguoi-dan-ong-bi-phat-1-25-trieu-dong-20250809083703498.htm",
      "summary": "Một người Đà Nẵng đưa du khách lên núi Sơn Trà khám phá. Thấy quả chòi mòi ở trên cao không hái được nên họ bẻ cành cây và bị xử phạt.",
      "source": "Tuổi Trẻ",
      "category": "Tổng hợp",
      "published": "2025-08-09T09:26:47.199398+07:00",
      "fetched": "2025-08-09T09:26:47.199544+07:00"
    },
    {
      "id": "86214590be47148c40d2e9c22bbd0b2d",
      "title": "Chốt đơn gây tò mò với hình ảnh Thùy Tiên thay bằng AI",
      "link": "https://tuoitre.vn/chot-don-gay-to-mo-voi-hinh-anh-thuy-tien-thay-bang-ai-20250808193146402.htm",
      "summary": "Một số tin tức xem nghe nổi bật: Em xinh say hi bỗng hóa anh trai; Thúy Diễm, Kim Tuyến đối đầu trong Chạy đến ngày hôm qua; Chuyện hồi đó của bác sĩ Đỗ Hồng Ngọc...",
      "source": "Tuổi Trẻ",
      "category": "Tổng hợp",
      "published": "2025-08-09T09:26:47.199176+07:00",
      "fetched": "2025-08-09T09:26:47.199382+07:00"
    },
    {
      "id": "5f74c4829f7bbeb6597e654d14137349",
      "title": "Giá xăng dầu hôm nay 9.8.2025: Tuần lao dốc mất 5%",
      "link": "https://thanhnien.vn/gia-xang-dau-hom-nay-982025-tuan-lao-doc-mat-5-185250809083531663.htm",
      "summary": "Giá dầu thế giới tăng nhẹ trong phiên giao dịch cuối tuần, tuy vậy, do giảm đến 4 phiên trong tuần, dầu tuần này lao dốc mất khoảng 5%. Dự báo, giá xăng dầu trong nước có thể giảm mạnh trong tuần tới.",
      "source": "Thanh Niên",
      "category": "Tổng hợp",
      "published": "2025-08-09T02:23:00+07:00",
      "fetched": "2025-08-09T09:26:46.225709+07:00"
    },
    {
      "id": "ebdc28e0649af3c359e932117a7fa20b",
      "title": "Cảnh báo người dùng ví điện tử cẩn thận với chiêu trò mạo danh lừa đảo",
      "link": "https://thanhnien.vn/canh-bao-nguoi-dung-vi-dien-tu-can-than-voi-chieu-tro-mao-danh-lua-dao-185250809090339586.htm",
      "summary": "Một số chiêu trò mạo danh lừa đảo mà người dùng ví điện tử nên quan tâm cảnh giác.",
      "source": "Thanh Niên",
      "category": "Tổng hợp",
      "published": "2025-08-09T02:17:00+07:00",
      "fetched": "2025-08-09T09:26:46.225877+07:00"
    },
    {
      "id": "021391f536860cc07013b29e5f2fdef6",
      "title": "Lớp dạy ngoại ngữ miễn phí, ai cũng theo học được",
      "link": "https://thanhnien.vn/lop-day-ngoai-ngu-mien-phi-ai-cung-theo-hoc-duoc-185250808203139296.htm",
      "summary": "Có một lớp học đặc biệt tổ chức dạy ngoại ngữ miễn phí dành cho mọi lứa tuổi. Ngoài ra, lớp còn dạy kỹ năng dẫn chương trình nhằm giúp học viên rèn luyện khả năng giao tiếp và thuyết trình trước đám đông.",
      "source": "Thanh Niên",
      "category": "Tổng hợp",
      "published": "2025-08-09T02:14:00+07:00",
      "fetched": "2025-08-09T09:26:46.226034+07:00"
    },
    {
      "id": "4f32a6821ff4bdea70b4a3207d5e0a97",
      "title": "Người nước ngoài diện đặc biệt nào được miễn visa vào Việt Nam?",
      "link": "https://thanhnien.vn/nguoi-nuoc-ngoai-dien-dac-biet-nao-duoc-mien-visa-vao-viet-nam-185250808222839853.htm",
      "summary": "Chính phủ vừa ban hành Nghị định số 221 quy định về việc miễn thị thực (miễn visa) có thời hạn cho người nước ngoài thuộc diện đối tượng đặc biệt cần ưu đãi phục vụ phát triển kinh tế - xã hội.",
      "source": "Thanh Niên",
      "category": "Tổng hợp",
      "published": "2025-08-09T02:07:00+07:00",
      "fetched": "2025-08-09T09:26:46.226188+07:00"
    },
    {
      "id": "df6ea20a18c4d97791b02f37197b1dcd",
      "title": "Nghịch lý tuyển sinh ngành y, dược trong 6 quyết định xử phạt một trường đại học",
      "link": "https://thanhnien.vn/nghich-ly-tuyen-sinh-nganh-y-duoc-trong-6-quyet-dinh-xu-phat-mot-truong-dai-hoc-185250808220115197.htm",
      "summary": "Với 6 quyết định xử phạt mà Trường ĐH Kinh Bắc vừa bị nhận, nhà trường không chỉ gần như bị ngừng hoạt động đào tạo mà còn ẩn chứa một nghịch lý hiện nay trong tuyển sinh, đào tạo các ngành y, dược.",
      "source": "Thanh Niên",
      "category": "Tổng hợp",
      "published": "2025-08-09T02:07:00+07:00",
      "fetched": "2025-08-09T09:26:46.226341+07:00"
    },
    {
      "id": "690df6939d58b9a38ef298f57890c0bd",
      "title": "Vì sao chỉ cần ‘chạm’ là thanh toán xong?",
      "link": "https://vnexpress.net/vi-sao-chi-can-cham-la-thanh-toan-xong-4924723.html",
      "summary": "Chỉ cần chạm nhẹ điện thoại vào máy thanh toán, chưa đầy một giây sau giao dịch đã hoàn tất – không dây, không tiếp xúc, công nghệ đứng sau cú chạm ấy là NFC.",
      "source": "VnExpress",
      "category": "Tổng hợp",
      "published": "2025-08-09T02:05:12+07:00",
      "fetched": "2025-08-09T09:26:41.716851+07:00"
    },
    {
      "id": "5213fdf1b986836ee68613e0d6f93c62",
      "title": "Nhồi máu não do bỏ insulin chữa bệnh tiểu đường",
      "link": "https://vnexpress.net/nhoi-mau-nao-do-bo-insulin-chua-benh-tieu-duong-4924717.html",
      "summary": "Người phụ nữ 30 tuổi bệnh đái tháo đường 15 năm, tự ý bỏ thuốc insulin dẫn tới nhồi máu não, di chứng liệt nửa người phải, cơ thể suy kiệt.",
      "source": "VnExpress",
      "category": "Tổng hợp",
      "published": "2025-08-09T02:05:05+07:00",
      "fetched": "2025-08-09T09:26:41.717046+07:00"
    },
    {
      "id": "b047902cfb7a09321fce857dec8dc92e",
      "title": "Barca trả lại băng đội trưởng cho Ter Stegen",
      "link": "https://vnexpress.net/barca-tra-lai-bang-doi-truong-cho-ter-stegen-4924703.html",
      "summary": "Do đồng ý ký vào báo cáo y tế, thủ môn Marc-Andre ter Stegen nhanh chóng được ban lãnh đạo Barca khôi phục vai trò thủ quân.",
      "source": "VnExpress",
      "category": "Tổng hợp",
      "published": "2025-08-09T02:05:02+07:00",
      "fetched": "2025-08-09T09:26:41.717280+07:00"
    },
    {
      "id": "b047902cfb7a09321fce857dec8dc92e",
      "title": "Barca trả lại băng đội trưởng cho Ter Stegen",
      "link": "https://vnexpress.net/barca-tra-lai-bang-doi-truong-cho-ter-stegen-4924703.html",
      "summary": "Do đồng ý ký vào báo cáo y tế, thủ môn Marc-Andre ter Stegen nhanh chóng được ban lãnh đạo Barca khôi phục vai trò thủ quân.",
      "source": "VnExpress - Thể Thao",
      "category": "Thể thao",
      "published": "2025-08-09T02:05:02+07:00",
      "fetched": "2025-08-09T09:26:55.404934+07:00"
    },
    {
      "id": "24504b095dc15f14c1dd361b75a1e1a1",
      "title": "Ông Trump có thể triển khai quân đội đối phó băng đảng ma túy Mỹ Latin",
      "link": "https://vnexpress.net/ong-trump-co-the-trien-khai-quan-doi-doi-pho-bang-dang-ma-tuy-my-latin-4924706.html",
      "summary": "Ông Trump có thể triển khai quân đội nhắm vào các băng đảng ma túy Mỹ Latin, sau khi Washington xác định một số nhóm là tổ chức khủng bố.",
      "source": "VnExpress",
      "category": "Tổng hợp",
      "published": "2025-08-09T02:03:48+07:00",
      "fetched": "2025-08-09T09:26:41.717448+07:00"
    },
    {
      "id": "24504b095dc15f14c1dd361b75a1e1a1",
      "title": "Ông Trump có thể triển khai quân đội đối phó băng đảng ma túy Mỹ Latin",
      "link": "https://vnexpress.net/ong-trump-co-the-trien-khai-quan-doi-doi-pho-bang-dang-ma-tuy-my-latin-4924706.html",
      "summary": "Ông Trump có thể triển khai quân đội nhắm vào các băng đảng ma túy Mỹ Latin, sau khi Washington xác định một số nhóm là tổ chức khủng bố.",
      "source": "VnExpress - Thế Giới",
      "category": "Thế giới",
      "published": "2025-08-09T02:03:48+07:00",
      "fetched": "2025-08-09T09:26:49.149863+07:00"
    },
    {
      "id": "ac24e7704b8addc80f733646c02b219e",
      "title": "Madam Pang bất ngờ làm người mẫu, bán áo phông giúp bóng đá Thái Lan trả nợ",
      "link": "https://thanhnien.vn/madam-pang-bat-ngo-lam-nguoi-mau-ban-ao-phong-giup-bong-da-thai-lan-tra-no-185250809085607116.htm",
      "summary": "Madam Pang (nữ tỉ phú Nualphan Lamsam), Chủ tịch Liên đoàn Bóng đá Thái Lan (FAT), khẳng định bà không ngại làm người mẫu để mặc những chiếc áo phông vừa ra mắt, khuyến khích CĐV mua để giúp bóng đá nước này vượt khủng hoảng nợ nần.",
      "source": "Thanh Niên",
      "category": "Tổng hợp",
      "published": "2025-08-09T02:01:00+07:00",
      "fetched": "2025-08-09T09:26:46.226491+07:00"
    },
    {
      "id": "439f77319f643612be9fc6d9360e32b2",
      "title": "Vì sao sân bay Gia Bình cần nâng công suất 50 triệu hành khách?",
      "link": "https://vnexpress.net/vi-sao-san-bay-gia-binh-can-nang-cong-suat-50-trieu-hanh-khach-4924438.html",
      "summary": "Sân bay quốc tế Gia Bình (Bắc Ninh) được quy hoạch mở rộng, nâng công suất lên 50 triệu hành khách nhằm giảm tải cho sân bay Nội Bài và đáp ứng nhu cầu của khu vực Đông Bắc.",
      "source": "VnExpress",
      "category": "Tổng hợp",
      "published": "2025-08-09T02:00:00+07:00",
      "fetched": "2025-08-09T09:26:41.717632+07:00"
    },
    {
      "id": "3589e3ae37e6a80d019e2338b0e78ff6",
      "title": "Tái tạo ngực sau ba năm đoạn nhũ chữa ung thư vú",
      "link": "https://vnexpress.net/tai-tao-nguc-sau-ba-nam-doan-nhu-chua-ung-thu-vu-4924709.html",
      "summary": "Chị Hạnh, 40 tuổi, ba năm trước được đoạn nhũ trái điều trị ung thư vú, nay từ Đài Loan về Việt Nam phẫu thuật tái tạo ngực.",
      "source": "VnExpress",
      "category": "Tổng hợp",
      "published": "2025-08-09T02:00:00+07:00",
      "fetched": "2025-08-09T09:26:41.717794+07:00"
    },
    {
      "id": "83a29b9ba187e448471c8e9abd8b47ff",
      "title": "Game chiến thuật top đầu Trung Quốc sắp phát hành tại Việt Nam",
      "link": "https://vnexpress.net/game-chien-thuat-top-dau-trung-quoc-sap-phat-hanh-tai-viet-nam-4923546.html",
      "summary": "Game Công thành truyền kỳ: Tam quốc, từng đứng đầu bảng xếp hạng App Store Trung Quốc, phát hành tại Việt Nam ngày 14/8 kèm nhiều quà tặng cho người chơi.",
      "source": "VnExpress",
      "category": "Tổng hợp",
      "published": "2025-08-09T02:00:00+07:00",
      "fetched": "2025-08-09T09:26:41.717950+07:00"
    },
    {
      "id": "b3f3ad1c4768f89e2db30952f37b3dc5",
      "title": "Van Phuc Group khởi công dự án Diamond Sky gần 2 ha",
      "link": "https://vnexpress.net/van-phuc-group-khoi-cong-du-an-diamond-sky-gan-2-ha-4923274.html",
      "summary": "Van Phuc Group tổ chức lễ khởi công khu phức hợp căn hộ và trung tâm thương mại Diamond Sky gần 2 ha tại khu đô thị Vạn Phúc (Van Phuc City), TP HCM, ngày 8/8.",
      "source": "VnExpress",
      "category": "Tổng hợp",
      "published": "2025-08-09T02:00:00+07:00",
      "fetched": "2025-08-09T09:26:41.718110+07:00"
    },
    {
      "id": "703c973386ca7831cc634497093db166",
      "title": "30 năm phát triển cùng Việt Nam của Acecook",
      "link": "https://vnexpress.net/30-nam-phat-trien-cung-viet-nam-cua-acecook-4923131.html",
      "summary": "Ba thập niên phát triển tại Việt Nam, Acecook mang đến những sản phẩm tiện lợi, góp phần nâng tầm thị trường mì ăn liền Việt Nam, ghi dấu tại nhiều cột mốc quan trọng.",
      "source": "VnExpress",
      "category": "Tổng hợp",
      "published": "2025-08-09T02:00:00+07:00",
      "fetched": "2025-08-09T09:26:41.718278+07:00"
    },
    {
      "id": "52be3c98cc02a12bc1302e07995c2498",
      "title": "Lợi thế khi du học THPT nội trú Mỹ",
      "link": "https://vnexpress.net/loi-the-khi-du-hoc-thpt-noi-tru-my-4920680.html",
      "summary": "Du học THPT, nhất là môi trường nội trú giúp học sinh sớm thích nghi với phương pháp học và lối sống Mỹ, tạo lợi thế cho hồ sơ đại học sau này.",
      "source": "VnExpress",
      "category": "Tổng hợp",
      "published": "2025-08-09T02:00:00+07:00",
      "fetched": "2025-08-09T09:26:41.718450+07:00"
    },
    {
      "id": "22bc6924616341072eae8594010d6d02",
      "title": "The Smith Entertainment tiếp nối tinh thần yêu nước cùng 'Viết tiếp câu chuyện hòa bình'",
      "link": "https://thanhnien.vn/the-smith-entertainment-tiep-noi-tinh-than-yeu-nuoc-cung-viet-tiep-cau-chuyen-hoa-binh-185250808213656636.htm",
      "summary": "Tối ngày 2.8.2025, tại cụm huấn luyện Đại học Quốc gia Hà Nội (Hòa Lạc), chương trình nghệ thuật đặc biệt 'Viết tiếp câu chuyện hòa bình' đã diễn ra, mang đến một không gian nghệ thuật đầy cảm xúc.",
      "source": "Thanh Niên",
      "category": "Tổng hợp",
      "published": "2025-08-09T02:00:00+07:00",
      "fetched": "2025-08-09T09:26:46.226666+07:00"
    },
    {
      "id": "703c973386ca7831cc634497093db166",
      "title": "30 năm phát triển cùng Việt Nam của Acecook",
      "link": "https://vnexpress.net/30-nam-phat-trien-cung-viet-nam-cua-acecook-4923131.html",
      "summary": "Ba thập niên phát triển tại Việt Nam, Acecook mang đến những sản phẩm tiện lợi, góp phần nâng tầm thị trường mì ăn liền Việt Nam, ghi dấu tại nhiều cột mốc quan trọng.",
      "source": "VnExpress - Kinh Doanh",
      "category": "Kinh doanh",
      "published": "2025-08-09T02:00:00+07:00",
      "fetched": "2025-08-09T09:26:51.089423+07:00"
    },
    {
      "id": "cb9f0bf9505482d0d88d83a8bbf11028",
      "title": "Toyota: các nhà cung ứng ở Việt Nam chưa làm được linh kiện khó",
      "link": "https://vnexpress.net/toyota-cac-nha-cung-ung-o-viet-nam-chua-lam-duoc-linh-kien-kho-4924501.html",
      "summary": "Hãng xe Nhật Bản cho rằng khó khăn lớn nhất để mở rộng khả năng nội địa hóa nằm ở chỗ các nhà cung cấp chưa làm được linh kiện khó.",
      "source": "VnExpress",
      "category": "Tổng hợp",
      "published": "2025-08-09T01:58:37+07:00",
      "fetched": "2025-08-09T09:26:41.718635+07:00"
    },
    {
      "id": "32c27f7199e8c6d42388baeb15187608",
      "title": "Giá USD hôm nay 9.8.2025: Ngân hàng tăng trở lại gần mức kỷ lục",
      "link": "https://thanhnien.vn/gia-usd-hom-nay-982025-ngan-hang-tang-tro-lai-gan-muc-ky-luc-185250809084550023.htm",
      "summary": "USD trong ngân hàng tăng trở lại 26.400 đồng/USD, lên gần mức cao kỷ lục. So với đầu năm, tỷ giá hiện tăng khoảng 850 đồng, tương đương 3,3%.",
      "source": "Thanh Niên",
      "category": "Tổng hợp",
      "published": "2025-08-09T01:53:00+07:00",
      "fetched": "2025-08-09T09:26:46.226822+07:00"
    },
    {
      "id": "8e0bbe895f33a7019825290656a57263",
      "title": "Du thuyền mất điện chở hơn 2.000 người trôi dạt trên biển",
      "link": "https://thanhnien.vn/du-thuyen-mat-dien-cho-hon-2000-nguoi-troi-dat-tren-bien-185250809081345816.htm",
      "summary": "Constellation, du thuyền của hãng Celebrity Cruises đã trôi dạt ba giờ ngoài khơi bờ biển Ý sau khi bị mất điện.",
      "source": "Thanh Niên",
      "category": "Tổng hợp",
      "published": "2025-08-09T01:49:00+07:00",
      "fetched": "2025-08-09T09:26:46.226972+07:00"
    },
    {
      "id": "63e5ca736660b5ce0033028262809758",
      "title": "Giá vàng hôm nay 9.8.2025: Neo ở mức kỷ lục, bỏ xa thế giới",
      "link": "https://thanhnien.vn/gia-vang-hom-nay-982025-neo-o-muc-ky-luc-bo-xa-the-gioi-185250809074326996.htm",
      "summary": "Giá vàng trong nước neo cao ở mức kỷ lục mới và tiếp tục bỏ xa thế giới.",
      "source": "Thanh Niên",
      "category": "Tổng hợp",
      "published": "2025-08-09T01:46:00+07:00",
      "fetched": "2025-08-09T09:26:46.227122+07:00"
    },
    {
      "id": "75ecae8e407d591d771e4cd174e8af27",
      "title": "Nhu cầu xử lý AI thúc đẩy thiết kế mới cho hệ thống trên ô tô",
      "link": "https://thanhnien.vn/nhu-cau-xu-ly-ai-thuc-day-thiet-ke-moi-cho-he-thong-tren-o-to-18525080611100214.htm",
      "summary": "Sự phát triển của AI (trí tuệ nhân tạo) trong ngành ô tô đang thúc đẩy việc tái thiết kế nền tảng điện toán, nhằm đáp ứng yêu cầu xử lý dữ liệu phức tạp và đảm bảo an toàn cho các hệ thống lái tự động.",
      "source": "Thanh Niên",
      "category": "Tổng hợp",
      "published": "2025-08-09T01:37:00+07:00",
      "fetched": "2025-08-09T09:26:46.227275+07:00"
    },
    {
      "id": "ed9feecb0597668e66dbddb8c43463a7",
      "title": "Cầu trượt trên du thuyền lớn nhất thế giới bất ngờ vỡ khi khách đang chơi",
      "link": "https://thanhnien.vn/cau-truot-tren-du-thuyen-lon-nhat-the-gioi-bat-ngo-vo-khi-khach-dang-choi-185250809083056571.htm",
      "summary": "Cầu trượt nước trên chiếc du thuyền Icon of the Seas bị nứt, tạo thành cạnh nhọn cắt vào người du khách đang trượt xuống.",
      "source": "Thanh Niên",
      "category": "Tổng hợp",
      "published": "2025-08-09T01:36:00+07:00",
      "fetched": "2025-08-09T09:26:46.227427+07:00"
    },
    {
      "id": "e525a75642455eeaeef6e46b623ccf69",
      "title": "Nóng: Việt Nam miễn thị thực cho cầu thủ tốp 100 thế giới, ngôi sao nào từng ghé qua?",
      "link": "https://thanhnien.vn/nong-viet-nam-mien-thi-thuc-cho-cau-thu-top-100-the-gioi-ngoi-sao-nao-tung-ghe-qua-185250809082726631.htm",
      "summary": "Chính phủ vừa ban hành Nghị định 221/2025 với điểm mới đáng chú ý về việc miễn thị thực có thời hạn cho các tài năng thể thao. Trong đó, cầu thủ đang thuộc tốp 100 thế giới cũng nằm trong diện này.",
      "source": "Thanh Niên",
      "category": "Tổng hợp",
      "published": "2025-08-09T01:36:00+07:00",
      "fetched": "2025-08-09T09:26:46.227596+07:00"
    },
    {
      "id": "9dc8adb991def89b8700e2f20f28e9fa",
      "title": "Ông Trump muốn phạt đại học Mỹ một tỷ USD",
      "link": "https://vnexpress.net/ong-trump-muon-phat-dai-hoc-my-mot-ty-usd-4924696.html",
      "summary": "Ông Trump yêu cầu Đại học California nộp phạt một tỷ USD, liên quan cáo buộc trường có hành vi bài Do Thái khi ứng phó biểu tình sinh viên.",
      "source": "VnExpress",
      "category": "Tổng hợp",
      "published": "2025-08-09T01:35:18+07:00",
      "fetched": "2025-08-09T09:26:41.718798+07:00"
    },
    {
      "id": "9dc8adb991def89b8700e2f20f28e9fa",
      "title": "Ông Trump muốn phạt đại học Mỹ một tỷ USD",
      "link": "https://vnexpress.net/ong-trump-muon-phat-dai-hoc-my-mot-ty-usd-4924696.html",
      "summary": "Ông Trump yêu cầu Đại học California nộp phạt một tỷ USD, liên quan cáo buộc trường có hành vi bài Do Thái khi ứng phó biểu tình sinh viên.",
      "source": "VnExpress - Thế Giới",
      "category": "Thế giới",
      "published": "2025-08-09T01:35:18+07:00",
      "fetched": "2025-08-09T09:26:49.150038+07:00"
    },
    {
      "id": "a865603e303d44dba0c31fb2d65e518c",
      "title": "Cả công ty ngưỡng mộ chồng tôi, giờ anh khiến tôi mất ngủ",
      "link": "https://vnexpress.net/ca-cong-ty-nguong-mo-chong-toi-gio-anh-khien-toi-mat-ngu-4924563.html",
      "summary": "Tôi đang mang bầu bé thứ hai, bàng hoàng khi chồng có nhiều hành vi bí ẩn.",
      "source": "VnExpress",
      "category": "Tổng hợp",
      "published": "2025-08-09T01:34:49+07:00",
      "fetched": "2025-08-09T09:26:41.718955+07:00"
    },
    {
      "id": "3d4e3b0dfd4b5c8fa32d0813b0ea98fa",
      "title": "Ngành ôtô Mỹ xao nhãng xe điện, trở lại với các cỗ máy ngốn xăng",
      "link": "https://vnexpress.net/nganh-oto-my-xao-nhang-xe-dien-tro-lai-voi-cac-co-may-ngon-xang-4923970.html",
      "summary": "Các \"ông lớn\" như Ford, General Motors, Stellantis đứng trước cơ hội kiếm nhiều lợi nhuận hơn nhờ các mẫu xe cỡ lớn, tiêu hao nhiên liệu.",
      "source": "VnExpress",
      "category": "Tổng hợp",
      "published": "2025-08-09T01:33:32+07:00",
      "fetched": "2025-08-09T09:26:41.719112+07:00"
    },
    {
      "id": "47e49ddd9d33867793200e272f3ddaa3",
      "title": "Lisa tỏa sáng dưới ống kính nhiếp ảnh gia Pháp",
      "link": "https://vnexpress.net/lisa-toa-sang-duoi-ong-kinh-nhiep-anh-gia-phap-4924596.html",
      "summary": "Nicolas Gerardin - nhiếp ảnh gia Pháp chuyên mảng thời trang, người nổi tiếng - nói thích chụp Lisa vì cô tạo dáng chuyên nghiệp, tỏa sáng mọi khoảnh khắc.",
      "source": "VnExpress",
      "category": "Tổng hợp",
      "published": "2025-08-09T01:19:21+07:00",
      "fetched": "2025-08-09T09:26:41.719267+07:00"
    },
    {
      "id": "0aa47a28689319873c300af71df88cfe",
      "title": "Bạn hiểu gì về những thuật ngữ thông dụng trong tiền số?",
      "link": "https://vnexpress.net/ban-hieu-gi-ve-nhung-thuat-ngu-thong-dung-trong-tien-so-4924416.html",
      "summary": "Blockchain, hợp đồng thông minh, DeFi, ví lưu trữ, khóa công khai, khóa riêng tư... là những thuật ngữ thông dụng trong tiền số, liệu bạn đã hiểu rõ?",
      "source": "VnExpress - Kinh Doanh",
      "category": "Kinh doanh",
      "published": "2025-08-09T01:06:23+07:00",
      "fetched": "2025-08-09T09:26:51.089265+07:00"
    },
    {
      "id": "fbf2efb773c847eb142e18927db699be",
      "title": "Hy hữu: Gặp khách 'ngáo đá', tài xế xe công nghệ lao vào chốt CSGT cầu cứu",
      "link": "https://thanhnien.vn/hy-huu-gap-khach-ngao-da-tai-xe-xe-cong-nghe-lao-vao-chot-csgt-cau-cuu-18525080908000934.htm",
      "summary": "Thấy vị khách có biểu hiện 'ngáo đá', liên tục hăm dọa và không chịu xuống xe dù đã đến nơi, tài xế  nhanh trí lái xe vào chốt CSGT để cầu cứu.",
      "source": "Thanh Niên",
      "category": "Tổng hợp",
      "published": "2025-08-09T01:06:00+07:00",
      "fetched": "2025-08-09T09:26:46.227753+07:00"
    },
    {
      "id": "c8bf5f57ea2ace642f901e0ce1888846",
      "title": "Chạy xe máy ngoài đường trời nắng nóng: Cần lưu ý gì?",
      "link": "https://thanhnien.vn/chay-xe-may-ngoai-duong-troi-nang-nong-can-luu-y-gi-185250809075049498.htm",
      "summary": "Trời nắng nóng gay gắt, người chạy xe máy, giao hàng hay tài xế công nghệ không chỉ chịu đựng mệt mỏi mà còn đối mặt nguy cơ sốc nhiệt – tình trạng cấp cứu nguy hiểm có thể đe dọa tính mạng nếu không được phát hiện và xử trí kịp thời.",
      "source": "Thanh Niên",
      "category": "Tổng hợp",
      "published": "2025-08-09T01:06:00+07:00",
      "fetched": "2025-08-09T09:26:46.227913+07:00"
    },
    {
      "id": "52ea13ff72c98893c03358558dfeb552",
      "title": "Robot chó Trung Quốc nâng người nặng 100 kg",
      "link": "https://vnexpress.net/robot-cho-trung-quoc-nang-nguoi-nang-100-kg-4924637.html",
      "summary": "Công ty Unitree Robotics giới thiệu chó robot 4 chân mới có khả năng di chuyển trên nhiều địa hình, chịu tải ấn tượng, ứng dụng trong môi trường khắc nghiệt.",
      "source": "VnExpress - Công Nghệ",
      "category": "Công nghệ",
      "published": "2025-08-09T01:00:00+07:00",
      "fetched": "2025-08-09T09:26:54.402680+07:00"
    },
    {
      "id": "3f37aff49082a19cba0e76de25c79e40",
      "title": "'Cơn ác mộng' thuế vào Mỹ 39% của ngành đồng hồ Thụy Sĩ",
      "link": "https://vnexpress.net/con-ac-mong-thue-vao-my-39-cua-nganh-dong-ho-thuy-si-4924507.html",
      "summary": "Một số lãnh đạo ngành đồng hồ Thụy Sĩ xem thuế quan 39% của ông Trump là \"cơn ác mộng\" vì có thể đẩy giá bán tại Mỹ tăng 65%.",
      "source": "VnExpress - Kinh Doanh",
      "category": "Kinh doanh",
      "published": "2025-08-09T00:33:51+07:00",
      "fetched": "2025-08-09T09:26:51.088930+07:00"
    },
    {
      "id": "318a72a78b25f2c6fd9da32fb19f7b63",
      "title": "Tổng thống Mỹ: Armenia - Azerbaijan cam kết dừng xung đột mãi mãi",
      "link": "https://vnexpress.net/tong-thong-my-armenia-azerbaijan-cam-ket-dung-xung-dot-mai-mai-4924695.html",
      "summary": "Tổng thống Trump tuyên bố Armenia và Azerbaijan đã cam kết hướng tới nền hòa bình lâu dài sau nhiều thập kỷ giao tranh sau cuộc gặp tại Nhà Trắng.",
      "source": "VnExpress - Thế Giới",
      "category": "Thế giới",
      "published": "2025-08-09T00:26:15+07:00",
      "fetched": "2025-08-09T09:26:49.150201+07:00"
    },
    {
      "id": "822740371baa61652a565a6a1dcac3f6",
      "title": "Turbine gió hai cánh độc đáo của Trung Quốc",
      "link": "https://vnexpress.net/turbine-gio-hai-canh-doc-dao-cua-trung-quoc-4924149.html",
      "summary": "Turbine gió hai cánh của công ty Envision Energy dễ vận chuyển và triển khai hơn, có thể thay thế thiết kế ba cánh ở khu vực xa xôi có cơ sở hạ tầng hạn chế.",
      "source": "VnExpress - Công Nghệ",
      "category": "Công nghệ",
      "published": "2025-08-09T00:00:00+07:00",
      "fetched": "2025-08-09T09:26:54.402857+07:00"
    },
    {
      "id": "86cfe8c1629a76c2f733090277ffff8f",
      "title": "Ông Trump sẽ gặp ông Putin tại Alaska vào tuần sau",
      "link": "https://vnexpress.net/ong-trump-se-gap-ong-putin-tai-alaska-vao-tuan-sau-4924690.html",
      "summary": "Mỹ và Nga xác nhận hội thượng đỉnh giữa Tổng thống Trump và người đồng cấp Vladimir Putin sẽ diễn ra tại bang Alaska vào ngày 15/8.",
      "source": "VnExpress - Thế Giới",
      "category": "Thế giới",
      "published": "2025-08-08T23:43:46+07:00",
      "fetched": "2025-08-09T09:26:49.150360+07:00"
    },
    {
      "id": "8dfcb90ec04a3af6a28299e0f6b4c1f2",
      "title": "'Cuộc đua Tử thần' 118 km qua dãy núi nguy hiểm nhất Canada",
      "link": "https://vnexpress.net/cuoc-dua-tu-than-118-km-qua-day-nui-nguy-hiem-nhat-canada-4924686.html",
      "summary": "Bất chấp cái tên không mấy lạc quan, Canadian Death Race (Cuộc đua Tử thần) vẫn thu hút hàng trăm runner tham gia trong mùa giải 2025, chinh phục 118 km đường núi hiểm trở ở dãy Rockies, Canada.",
      "source": "VnExpress - Thể Thao",
      "category": "Thể thao",
      "published": "2025-08-08T23:43:10+07:00",
      "fetched": "2025-08-09T09:26:55.405095+07:00"
    },
    {
      "id": "e56333b65e7c4f20d03f651d87f9cad6",
      "title": "Anh dùng drone thả bóng nước để huấn luyện lính Ukraine",
      "link": "https://vnexpress.net/anh-dung-drone-tha-bong-nuoc-de-huan-luyen-linh-ukraine-4924583.html",
      "summary": "Quân đội Anh dùng drone thả bóng nước mô phỏng lựu đạn nhằm huấn luyện binh sĩ Ukraine cách đối phó với phương tiện này.",
      "source": "VnExpress - Thế Giới",
      "category": "Thế giới",
      "published": "2025-08-08T23:37:27+07:00",
      "fetched": "2025-08-09T09:26:49.150533+07:00"
    },
    {
      "id": "ede2a98cca6a21e853621ec152ed048b",
      "title": "Ngôi sao WWE tái xuất giữa bê bối tình dục",
      "link": "https://vnexpress.net/ngoi-sao-wwe-tai-xuat-giua-be-boi-tinh-duc-4924641.html",
      "summary": "Brock Lesnar tái xuất tại sự kiện SummerSlam 2025 khiến làng đô vật Mỹ chấn động, khi tên anh vẫn đang bị nhắc đến trong vụ kiện liên quan đến cáo buộc buôn người và lạm dụng tình dục tại giải vô địch vật tự do WWE.",
      "source": "VnExpress - Thể Thao",
      "category": "Thể thao",
      "published": "2025-08-08T23:36:06+07:00",
      "fetched": "2025-08-09T09:26:55.405251+07:00"
    },
    {
      "id": "98eeefdae25c3a40c265579a28b70019",
      "title": "VĐV phá kỷ lục với cú nhảy tử thần từ độ cao hơn 48 m",
      "link": "https://vnexpress.net/vdv-pha-ky-luc-voi-cu-nhay-tu-than-tu-do-cao-hon-48-m-4924649.html",
      "summary": "Florian Marker, VĐV Đức có biệt danh \"Chucko\", thực hiện cú nhảy từ độ cao 48,7 mét để lập kỷ lục thế giới mới trong môn thể thao mạo hiểm nhảy tự do tử thần.",
      "source": "VnExpress - Thể Thao",
      "category": "Thể thao",
      "published": "2025-08-08T23:35:10+07:00",
      "fetched": "2025-08-09T09:26:55.405404+07:00"
    },
    {
      "id": "fc5ec844db58ee3c0cc1ca3e85911488",
      "title": "Ronaldo ám chỉ Champions League không bằng Saudi Pro League",
      "link": "https://vnexpress.net/ronaldo-am-chi-champions-league-khong-bang-saudi-pro-league-4924687.html",
      "summary": "Tiền đạo Cristiano Ronaldo ủng hộ đàn em đồng hương Joao Felix khước từ CLB đang thi đấu ở Champions League để chuyển đến Al Nassr.",
      "source": "VnExpress - Thể Thao",
      "category": "Thể thao",
      "published": "2025-08-08T23:08:30+07:00",
      "fetched": "2025-08-09T09:26:55.404419+07:00"
    },
    {
      "id": "65699c19ad1ba539b064afe536041887",
      "title": "Barca lĩnh loạt án phạt từ UEFA",
      "link": "https://vnexpress.net/barca-linh-loat-an-phat-tu-uefa-4924688.html",
      "summary": "HLV Hansi Flick, trợ lý Marcus Sorg cùng hai ngôi sao Robert Lewandowski và Lamine Yamal đều bị phạt sau trận Barca làm khách của Inter ở lượt về bán kết Champions League mùa 2024-2025.",
      "source": "VnExpress - Thể Thao",
      "category": "Thể thao",
      "published": "2025-08-08T23:02:57+07:00",
      "fetched": "2025-08-09T09:26:55.405576+07:00"
    },
    {
      "id": "30c8d300c1de3a4cb2cc90031afd6205",
      "title": "Đức hạn chế xuất khẩu vũ khí cho Israel",
      "link": "https://vnexpress.net/duc-han-che-xuat-khau-vu-khi-cho-israel-4924653.html",
      "summary": "Đức thông báo đình chỉ bán cho Israel khí tài có thể được sử dụng ở Gaza, nhằm phản ứng với kế hoạch kiểm soát Gaza City của Tel Aviv.",
      "source": "VnExpress - Thế Giới",
      "category": "Thế giới",
      "published": "2025-08-08T23:00:00+07:00",
      "fetched": "2025-08-09T09:26:49.150704+07:00"
    },
    {
      "id": "0d77d8ed951e131475ca5908f92ca60c",
      "title": "Người dân có thể nhận thuốc tại nhà qua VNeID từ tháng 9",
      "link": "https://vnexpress.net/nguoi-dan-co-the-nhan-thuoc-tai-nha-qua-vneid-tu-thang-9-4924661.html",
      "summary": "Bộ Công an thí điểm liên thông dữ liệu đơn thuốc, giúp người dân nhận thuốc tại nhà qua ứng dụng VNeID từ tháng 9, triển khai chính thức từ tháng 10/2025.",
      "source": "VnExpress - Công Nghệ",
      "category": "Công nghệ",
      "published": "2025-08-08T23:00:00+07:00",
      "fetched": "2025-08-09T09:26:54.403021+07:00"
    },
    {
      "id": "78bd9ea07fe3a711f80f780c3139dc15",
      "title": "Man Utd khánh thành Carrington mới trị giá gần 70 triệu USD",
      "link": "https://vnexpress.net/man-utd-khanh-thanh-carrington-moi-tri-gia-gan-70-trieu-usd-4924685.html",
      "summary": "Sau 12 tháng thi công với khoản đầu tư 67 triệu USD, trung tâm huấn luyện Carrington đã được cải tạo toàn diện, trở thành một trong những cơ sở hiện đại bậc nhất bóng đá châu Âu.",
      "source": "VnExpress - Thể Thao",
      "category": "Thể thao",
      "published": "2025-08-08T22:02:19+07:00",
      "fetched": "2025-08-09T09:26:55.404612+07:00"
    },
    {
      "id": "300d86a970dceda399e0a1af4d8cda47",
      "title": "Nỗ lực ngoại giao đưa ông Trump - Putin đến hội nghị thượng đỉnh",
      "link": "https://vnexpress.net/no-luc-ngoai-giao-dua-ong-trump-putin-den-hoi-nghi-thuong-dinh-4924138.html",
      "summary": "Cuộc gặp thượng đỉnh Mỹ - Nga tuần tới là kết quả của 6 tháng ngoại giao giữa hai bên để phá băng quan hệ, hướng đến chấm dứt chiến sự Ukraine.",
      "source": "VnExpress - Thế Giới",
      "category": "Thế giới",
      "published": "2025-08-08T22:00:00+07:00",
      "fetched": "2025-08-09T09:26:49.150864+07:00"
    },
    {
      "id": "978e92e0691cdd3b0ad32ed342bfaa48",
      "title": "Real tiếp tục ngó lơ Quả Bóng Vàng",
      "link": "https://vnexpress.net/real-tiep-tuc-ngo-lo-qua-bong-vang-4924658.html",
      "summary": "Real Madrid không đăng bất cứ thông tin nào chúc mừng các thành viên của đội bóng được đề cử Quả Bóng Vàng 2025.",
      "source": "VnExpress - Thể Thao",
      "category": "Thể thao",
      "published": "2025-08-08T21:57:43+07:00",
      "fetched": "2025-08-09T09:26:55.404777+07:00"
    },
    {
      "id": "9e69b2f099a639c59882cb21c7baddb6",
      "title": "Những người trẻ Canada vay nóng để trang trải cuộc sống",
      "link": "https://vnexpress.net/nhung-nguoi-tre-canada-vay-nong-de-trang-trai-cuoc-song-4923859.html",
      "summary": "Nhiều người trẻ Canada vật lộn với chi phí sinh hoạt cao, ngập trong nợ tín dụng, thậm chí vay nóng để trang trải nhu cầu.",
      "source": "VnExpress - Thế Giới",
      "category": "Thế giới",
      "published": "2025-08-08T20:00:00+07:00",
      "fetched": "2025-08-09T09:26:49.151015+07:00"
    },
    {
      "id": "20d08b050a0e1145c1b201fd44c4c08c",
      "title": "Khoảnh khắc cảnh sát Mỹ tay không bắt cá sấu",
      "link": "https://vnexpress.net/khoanh-khac-canh-sat-my-tay-khong-bat-ca-sau-4924480.html",
      "summary": "Sĩ quan cảnh sát Richardson ở Florida dùng tay không bắt sống con cá sấu đột nhập vào bể bơi nhà dân, khiến những người chứng kiến kinh ngạc.",
      "source": "VnExpress - Thế Giới",
      "category": "Thế giới",
      "published": "2025-08-08T19:00:00+07:00",
      "fetched": "2025-08-09T09:26:49.151180+07:00"
    },
    {
      "id": "f82ce68a588928d95497e2d3ad82352b",
      "title": "Vụ va chạm khiến tàu ngầm Mỹ thủng bụng ngoài khơi Nga năm 1992",
      "link": "https://vnexpress.net/vu-va-cham-khien-tau-ngam-my-thung-bung-ngoai-khoi-nga-nam-1992-4922958.html",
      "summary": "Tàu ngầm USS Baton Rouge của Mỹ làm nhiệm vụ cách bờ biển Nga chỉ 22 km, trước khi bị tàu Kostroma đâm trúng và chịu hư hại nghiêm trọng.",
      "source": "VnExpress - Thế Giới",
      "category": "Thế giới",
      "published": "2025-08-08T18:00:00+07:00",
      "fetched": "2025-08-09T09:26:49.151333+07:00"
    },
    {
      "id": "0240b0612978c917e0d03dcb26eeac28",
      "title": "Lãnh đạo Ấn Độ - Nga điện đàm về Ukraine",
      "link": "https://vnexpress.net/lanh-dao-an-do-nga-dien-dam-ve-ukraine-4924671.html",
      "summary": "Thủ tướng Ấn Độ Modi nói đã có cuộc điện đàm \"tốt đẹp\" với Tổng thống Nga Putin để thảo luận về xung đột Ukraine và quan hệ song phương.",
      "source": "VnExpress - Thế Giới",
      "category": "Thế giới",
      "published": "2025-08-08T17:15:34+07:00",
      "fetched": "2025-08-09T09:26:49.151486+07:00"
    },
    {
      "id": "c2c12868ee6d20a6252a8216b9949a96",
      "title": "Thế Giới Di Động sẽ niêm yết thêm chuỗi điện thoại và điện máy",
      "link": "https://vnexpress.net/the-gioi-di-dong-se-niem-yet-them-chuoi-dien-thoai-va-dien-may-4924675.html",
      "summary": "Ngoài Bách Hóa Xanh, MWG sẽ IPO và niêm yết thêm hai chuỗi Thế Giới Di Động và Điện Máy Xanh dự kiến vào năm 2030.",
      "source": "VnExpress - Kinh Doanh",
      "category": "Kinh doanh",
      "published": "2025-08-08T17:00:00+07:00",
      "fetched": "2025-08-09T09:26:51.089103+07:00"
    },
    {
      "id": "caf65636432629d0811aca1398acb1ee",
      "title": "Hệ thống AI có thể giúp máy bay gặp nạn thoát hiểm",
      "link": "https://vnexpress.net/he-thong-ai-co-the-giup-may-bay-gap-nan-thoat-hiem-4924153.html",
      "summary": "Hệ thống cứu sinh sử dụng AI của các nhà nghiên cứu ở Dubai có thể giảm đáng kể tốc độ và lực tác động khi máy bay có nguy cơ xảy ra tai nạn.",
      "source": "VnExpress - Công Nghệ",
      "category": "Công nghệ",
      "published": "2025-08-08T17:00:00+07:00",
      "fetched": "2025-08-09T09:26:54.403180+07:00"
    },
    {
      "id": "1968011ead99dd9fd0018eb555df2d81",
      "title": "CEO Intel nói gì khi bị ông Trump yêu cầu từ chức?",
      "link": "https://vnexpress.net/ceo-intel-noi-gi-khi-bi-ong-trump-yeu-cau-tu-chuc-4924657.html",
      "summary": "Trước việc bị Tổng thống Mỹ Donald Trump yêu cầu từ chức, CEO Intel Lip-Bu Tan khẳng định luôn tuân thủ pháp luật \"ở mức cao nhất\".",
      "source": "VnExpress - Công Nghệ",
      "category": "Công nghệ",
      "published": "2025-08-08T15:31:48+07:00",
      "fetched": "2025-08-09T09:26:54.403337+07:00"
    },
    {
      "id": "49a2c2971e7c0c44d4ac6c66f1032c12",
      "title": "MV 'Kiếp sau vẫn là người Việt Nam' bị nhận xét lạm dụng AI",
      "link": "https://vnexpress.net/mv-kiep-sau-van-la-nguoi-viet-nam-bi-nhan-xet-lam-dung-ai-4924481.html",
      "summary": "MV \"Kiếp sau vẫn là người Việt Nam\" bị khán giả nói thiếu chân thực do dùng AI quá đà, êkíp rút kinh nghiệm và gỡ video.",
      "source": "VnExpress - Công Nghệ",
      "category": "Công nghệ",
      "published": "2025-08-08T15:01:22+07:00",
      "fetched": "2025-08-09T09:26:54.403494+07:00"
    },
    {
      "id": "7da9581f0619b8e8c19cea2d57b43d6f",
      "title": "Việt Nam cam kết góp sức để ASEAN phát triển nhanh, bền vững",
      "link": "https://vnexpress.net/viet-nam-cam-ket-gop-suc-de-asean-phat-trien-nhanh-ben-vung-4924652.html",
      "summary": "Thủ tướng cho biết Việt Nam sẽ nỗ lực đưa ASEAN phát triển dựa trên khoa học, công nghệ và đổi mới sáng tạo, trong thông điệp nhân dịp 58 năm thành lập khối và 30 năm Việt Nam gia nhập.",
      "source": "VnExpress - Thế Giới",
      "category": "Thế giới",
      "published": "2025-08-08T14:45:47+07:00",
      "fetched": "2025-08-09T09:26:49.151656+07:00"
    },
    {
      "id": "c335c5039c2e36f41b9a180d759ec9d9",
      "title": "Thủ tướng Malaysia ca ngợi 'chặng đường ấn tượng' của Việt Nam tại ASEAN",
      "link": "https://vnexpress.net/thu-tuong-malaysia-ca-ngoi-chang-duong-an-tuong-cua-viet-nam-tai-asean-4924650.html",
      "summary": "Thủ tướng Malaysia Anwar Ibrahim nhận định Việt Nam đã có \"chặng đường ấn tượng\" tại ASEAN trong bài viết nhân kỷ niệm 30 năm Việt Nam gia nhập khối.",
      "source": "VnExpress - Thế Giới",
      "category": "Thế giới",
      "published": "2025-08-08T14:18:49+07:00",
      "fetched": "2025-08-09T09:26:49.151814+07:00"
    },
    {
      "id": "3fe8b702ee277e0089f1dbe6281946c5",
      "title": "Lũ quét ở tây bắc Trung Quốc, 10 người chết",
      "link": "https://vnexpress.net/lu-quet-o-tay-bac-trung-quoc-10-nguoi-chet-4924616.html",
      "summary": "10 người thiệt mạng, 33 người mất tích do lũ quét ở tỉnh Cam Túc của Trung Quốc, Chủ tịch Tập Cận Bình chỉ đạo dốc hết sức cứu nạn.",
      "source": "VnExpress - Thế Giới",
      "category": "Thế giới",
      "published": "2025-08-08T13:01:26+07:00",
      "fetched": "2025-08-09T09:26:49.151966+07:00"
    },
    {
      "id": "ebb6a3d32a42c8bf24c0d63ff278b7ac",
      "title": "Hàng Việt sang Mỹ nguy cơ chững lại trong quý III",
      "link": "https://vnexpress.net/hang-viet-sang-my-nguy-co-chung-lai-trong-quy-iii-4924500.html",
      "summary": "Hàng Việt sang Mỹ có thể chững lại từ quý III, khi doanh nghiệp nhập khẩu chờ chính sách cụ thể, cộng thêm lượng tồn kho từ đầu năm còn lớn, theo chuyên gia.",
      "source": "VnExpress - Kinh Doanh",
      "category": "Kinh doanh",
      "published": "2025-08-08T12:52:56+07:00",
      "fetched": "2025-08-09T09:26:51.089600+07:00"
    },
    {
      "id": "ca2fddcb5944529b0d1b91ec205cf766",
      "title": "CLB Công an TP HCM ra mắt",
      "link": "https://vnexpress.net/clb-cong-an-tp-hcm-ra-mat-4924496.html",
      "summary": "Đội bóng ngành công an vang bóng một thời của TP HCM chính thức tái xuất sân cỏ Việt Nam, tham dự V-League mùa 2025-2026.",
      "source": "VnExpress - Thể Thao",
      "category": "Thể thao",
      "published": "2025-08-08T12:50:34+07:00",
      "fetched": "2025-08-09T09:26:55.405737+07:00"
    },
    {
      "id": "cf1336d7279bc30a0890ced5150b8d9b",
      "title": "Nguyễn Xuân Son chấn thương vẫn được đăng ký dự Siêu cup Quốc gia",
      "link": "https://vnexpress.net/nguyen-xuan-son-chan-thuong-van-duoc-dang-ky-du-sieu-cup-quoc-gia-4924644.html",
      "summary": "Nam Định gây bất ngờ khi đăng ký tiền đạo nhập tịch Nguyễn Xuân Son chưa hồi phục chấn thương vào danh sách dự trận tranh Siêu cup Quốc gia 2024-2025 với Công an Hà Nội.",
      "source": "VnExpress - Thể Thao",
      "category": "Thể thao",
      "published": "2025-08-08T12:07:53+07:00",
      "fetched": "2025-08-09T09:26:55.405893+07:00"
    },
    {
      "id": "d063d7e3bb6e4ec4a7d6cf174a1c121c",
      "title": "Financial Times: Mỹ áp thuế nhập khẩu với vàng thỏi 1 kg",
      "link": "https://vnexpress.net/financial-times-my-ap-thue-nhap-khau-voi-vang-thoi-1-kg-4924630.html",
      "summary": "Mỹ có thể đã áp thuế lên các thỏi vàng 1 kg nhập vào nước này, với \"nạn nhân\" hàng đầu là Thụy Sĩ, theo nguồn tin của Financial Times.",
      "source": "VnExpress - Kinh Doanh",
      "category": "Kinh doanh",
      "published": "2025-08-08T12:06:01+07:00",
      "fetched": "2025-08-09T09:26:51.089759+07:00"
    },
    {
      "id": "cdac36ca660eba1fd1d8d0d9d1919909",
      "title": "Động lực thúc đẩy Tây Ban Nha hủy kế hoạch mua F-35",
      "link": "https://vnexpress.net/dong-luc-thuc-day-tay-ban-nha-huy-ke-hoach-mua-f-35-4924073.html",
      "summary": "Vấn đề chi phí, mong muốn giảm phụ thuộc vào Mỹ và thúc đẩy công nghiệp quốc phòng châu Âu dường như đã khiến Tây Ban Nha từ bỏ F-35.",
      "source": "VnExpress - Thế Giới",
      "category": "Thế giới",
      "published": "2025-08-08T12:00:00+07:00",
      "fetched": "2025-08-09T09:26:49.152118+07:00"
    },
    {
      "id": "21a14e8d0de889b317fc995fb6f0c2f3",
      "title": "Elon Musk ủng hộ xóa Instagram",
      "link": "https://vnexpress.net/elon-musk-ung-ho-xoa-instagram-4924366.html",
      "summary": "Elon Musk gây chú ý khi bình luận bài đăng của một CEO startup công nghệ về quyết định xóa tài khoản Instagram.",
      "source": "VnExpress - Công Nghệ",
      "category": "Công nghệ",
      "published": "2025-08-08T12:00:00+07:00",
      "fetched": "2025-08-09T09:26:54.403976+07:00"
    },
    {
      "id": "ce37109de49ae0e93eac61aa321c4530",
      "title": "JPMorgan dự báo Fed giảm lãi suất tháng 9",
      "link": "https://vnexpress.net/jpmorgan-du-bao-fed-giam-lai-suat-thang-9-4924568.html",
      "summary": "Thị trường lao động Mỹ yếu đi và sự thay đổi thành viên trong Fed khiến JPMorgan đẩy dự báo giảm lãi suất lên sớm 3 tháng.",
      "source": "VnExpress - Kinh Doanh",
      "category": "Kinh doanh",
      "published": "2025-08-08T10:05:00+07:00",
      "fetched": "2025-08-09T09:26:51.089911+07:00"
    },
    {
      "id": "79e8c22b464053bcb23ff68cd727681f",
      "title": "Garnacho đạt thỏa thuận với Chelsea",
      "link": "https://vnexpress.net/garnacho-dat-thoa-thuan-voi-chelsea-4924574.html",
      "summary": "Chelsea đạt thỏa thuận cá nhân với Alejandro Garnacho, nhưng vẫn cần trả mức phí chuyển nhượng theo yêu cầu của Man Utd để hoàn tất thương vụ.",
      "source": "VnExpress - Thể Thao",
      "category": "Thể thao",
      "published": "2025-08-08T09:35:07+07:00",
      "fetched": "2025-08-09T09:26:55.406043+07:00"
    },
    {
      "id": "3a32e6bd8f19f03e19e0dfca4e247a85",
      "title": "Tổng Bí thư: Tăng thu, tiết kiệm chi để đầu tư dự án lớn xoay chuyển tình thế",
      "link": "https://vnexpress.net/tong-bi-thu-tang-thu-tiet-kiem-chi-de-dau-tu-du-an-lon-xoay-chuyen-tinh-the-4924555.html",
      "summary": "Tổng Bí thư Tô Lâm yêu cầu ngành tài chính triệt để tiết kiệm chi thường xuyên, tăng thu, tập trung đầu tư phát triển một số dự án lớn mang tính chuyển đổi trạng thái, xoay chuyển tình thế.",
      "source": "VnExpress - Kinh Doanh",
      "category": "Kinh doanh",
      "published": "2025-08-08T09:28:18+07:00",
      "fetched": "2025-08-09T09:26:51.090063+07:00"
    },
    {
      "id": "97a6f46e12b942c8f00e0841fb00b5f3",
      "title": "Cổ phiếu Vingroup, VPBank kéo chứng khoán đảo chiều",
      "link": "https://vnexpress.net/chung-khoan-hom-nay-8-8-co-phieu-vingroup-vpbank-keo-vn-index-dao-chieu-4924535.html",
      "summary": "Áp lực bán chốt lời dâng cao từ nửa cuối buổi sáng khiến chứng khoán bị nhuộm đỏ trước khi đảo chiều vào cuối phiên nhờ VIC và VPB.",
      "source": "VnExpress - Kinh Doanh",
      "category": "Kinh doanh",
      "published": "2025-08-08T09:00:37+07:00",
      "fetched": "2025-08-09T09:26:51.090217+07:00"
    },
    {
      "id": "9698e40773b78d90538147fd5f0f90ce",
      "title": "Apple dừng bán, giảm giá một số mẫu iPhone tại Việt Nam",
      "link": "https://vnexpress.net/apple-dung-ban-giam-gia-mot-so-mau-iphone-tai-viet-nam-4924379.html",
      "summary": "Các hệ thống bán lẻ đồng loạt dừng kinh doanh iPhone 11, 12 và 14 Plus trong khi một số mẫu khác cũng được điều chỉnh giảm 5-6%.",
      "source": "VnExpress - Công Nghệ",
      "category": "Công nghệ",
      "published": "2025-08-08T08:53:27+07:00",
      "fetched": "2025-08-09T09:26:54.403668+07:00"
    },
    {
      "id": "adb0eea878d92733a8e5d5ff4f0a29e3",
      "title": "Lý do ông Trump đòi sa thải CEO Intel",
      "link": "https://vnexpress.net/ly-do-ong-trump-doi-sa-thai-ceo-intel-4924375.html",
      "summary": "Việc Tổng thống Mỹ Donald Trump yêu cầu CEO Intel từ chức được cho là liên quan đến loạt quỹ đầu tư mạo hiểm do ông Lip-Bu Tan điều hành.",
      "source": "VnExpress - Công Nghệ",
      "category": "Công nghệ",
      "published": "2025-08-08T07:41:31+07:00",
      "fetched": "2025-08-09T09:26:54.404130+07:00"
    },
    {
      "id": "66751b8d4730951b932959ddab3721a1",
      "title": "Quả Bóng Vàng: Từ thuở sơ khai đến thời đại Messi - Ronaldo",
      "link": "https://vnexpress.net/qua-bong-vang-tu-thuo-so-khai-den-thoi-dai-messi-ronaldo-4921710.html",
      "summary": "Giải thưởng cá nhân danh giá nhất trong bóng đá Ballon d'Or, tức Quả Bóng Vàng, thay đổi đáng kể từ khi được thành lập năm 1956, trong đó huy hoàng nhất là giai đoạn đua tranh giữa Lionel Messi và Cristiano Ronaldo.",
      "source": "VnExpress - Thể Thao",
      "category": "Thể thao",
      "published": "2025-08-08T07:00:00+07:00",
      "fetched": "2025-08-09T09:26:55.406201+07:00"
    },
    {
      "id": "af02755d7da1e8ccaf8c656a88cb070d",
      "title": "Cổ phiếu F88 tăng kịch trần, thị giá cao nhất sàn chứng khoán",
      "link": "https://vnexpress.net/co-phieu-f88-tang-kich-tran-thi-gia-cao-nhat-san-chung-khoan-4924433.html",
      "summary": "Hơn 8,26 triệu cổ phiếu F88 chào sàn UPCoM sáng nay và ngay khi mở cửa đã tăng kịch trần 40%, lên 888.800 đồng một cổ phiếu.",
      "source": "VnExpress - Kinh Doanh",
      "category": "Kinh doanh",
      "published": "2025-08-08T05:10:59+07:00",
      "fetched": "2025-08-09T09:26:51.090378+07:00"
    },
    {
      "id": "26083fc6198eb62a783cabbfd26109c9",
      "title": "Carlsen tự hào vì AI chơi cờ với suy nghĩ giống con người",
      "link": "https://vnexpress.net/carlsen-tu-hao-vi-ai-choi-co-voi-suy-nghi-giong-con-nguoi-4924371.html",
      "summary": "Kỳ thủ số một thế giới Magnus Carlsen cảm thấy tự hào khi những Mô hình Ngôn ngữ Lớn (LLM) thi đấu cờ vua với suy nghĩ giống con người.",
      "source": "VnExpress - Thể Thao",
      "category": "Thể thao",
      "published": "2025-08-08T04:51:56+07:00",
      "fetched": "2025-08-09T09:26:55.406358+07:00"
    },
    {
      "id": "266f96616df8323fb28eca4cef567dc2",
      "title": "Ông Trump đề cử thành viên Hội đồng Thống đốc Fed",
      "link": "https://vnexpress.net/ong-trump-de-cu-thanh-vien-hoi-dong-thong-doc-fed-4924422.html",
      "summary": "Tổng thống Mỹ Donald Trump cho biết sẽ đề cử Chủ tịch Hội đồng Cố vấn Kinh tế Stephen Miran tạm thời lấp vị trí còn trống trong Fed.",
      "source": "VnExpress - Kinh Doanh",
      "category": "Kinh doanh",
      "published": "2025-08-08T04:45:20+07:00",
      "fetched": "2025-08-09T09:26:51.090553+07:00"
    },
    {
      "id": "a94a48e445a1b8fd92609f3eb9de081d",
      "title": "Trung Quốc tạo ra siêu thép dùng cho lò phản ứng nhiệt hạch",
      "link": "https://vnexpress.net/trung-quoc-tao-ra-sieu-thep-dung-cho-lo-phan-ung-nhiet-hach-4923966.html",
      "summary": "Sau hơn một thập kỷ phát triển, các nhà khoa học Trung Quốc tạo ra loại thép mới có thể chịu từ trường 20 tesla và áp suất 1,3 GPa.",
      "source": "VnExpress - Công Nghệ",
      "category": "Công nghệ",
      "published": "2025-08-08T04:33:31+07:00",
      "fetched": "2025-08-09T09:26:54.404289+07:00"
    },
    {
      "id": "8a0fd15a863a1ea9a1cd7c3741b2a27d",
      "title": "Doanh nghiệp Việt không bị động trước thuế đối ứng của Mỹ",
      "link": "https://vnexpress.net/doanh-nghiep-viet-khong-bi-dong-truoc-thue-doi-ung-cua-my-4923899.html",
      "summary": "Chính sách thuế quan mới của Mỹ đặt ra thách thức nhất định, song không khiến các doanh nghiệp xuất khẩu bị động nhờ chuẩn bị tâm thế và phương án ứng phó.",
      "source": "VnExpress - Kinh Doanh",
      "category": "Kinh doanh",
      "published": "2025-08-08T04:32:16+07:00",
      "fetched": "2025-08-09T09:26:51.090717+07:00"
    },
    {
      "id": "a8541f5cd4bc9fd55f310866f27f99fa",
      "title": "Danh sách ứng viên Quả Bóng Vàng được tạo ra như thế nào",
      "link": "https://vnexpress.net/danh-sach-ung-vien-qua-bong-vang-duoc-tao-ra-nhu-the-nao-4924394.html",
      "summary": "Màn trình diễn cá nhân, thành tích tập thể, vị trí thi đấu, CLB... là những tiêu chí được xem xét trước khi các chuyên gia đưa ra danh sách 30 cầu thủ được đề cử cho Quả Bóng Vàng.",
      "source": "VnExpress - Thể Thao",
      "category": "Thể thao",
      "published": "2025-08-08T04:30:17+07:00",
      "fetched": "2025-08-09T09:26:55.406508+07:00"
    },
    {
      "id": "5b1bdeac2e66beca3c0c7b29bf6cdd76",
      "title": "Giá vàng miếng lập đỉnh mới, vượt 124 triệu đồng",
      "link": "https://vnexpress.net/gia-vang-mieng-lap-dinh-moi-vuot-124-trieu-dong-4924214.html",
      "summary": "Mỗi lượng vàng miếng chiều nay tăng thêm nửa triệu đồng, lập đỉnh mới gần 124,5 triệu đồng.",
      "source": "VnExpress - Kinh Doanh",
      "category": "Kinh doanh",
      "published": "2025-08-08T03:04:05+07:00",
      "fetched": "2025-08-09T09:26:51.090870+07:00"
    },
    {
      "id": "9b094400adb217fb4d0b23346ae2e728",
      "title": "Chính quyền ông Trump muốn thu hồi 7 tỷ USD đã giải ngân cho điện mặt trời",
      "link": "https://vnexpress.net/chinh-quyen-ong-trump-muon-thu-hoi-7-ty-usd-da-giai-ngan-cho-dien-mat-troi-4924204.html",
      "summary": "Mỹ tuyên bố chấm dứt chương trình tài trợ lắp đặt điện mặt trời 7 tỷ USD thời cựu Tổng thống Biden, dù đã giải ngân.",
      "source": "VnExpress - Kinh Doanh",
      "category": "Kinh doanh",
      "published": "2025-08-08T02:50:05+07:00",
      "fetched": "2025-08-09T09:26:51.091019+07:00"
    },
    {
      "id": "1b88b93c2724b01e6f5dd27bb5cef092",
      "title": "Những sự vắng mặt gây tiếc nuối ở Quả Bóng Vàng",
      "link": "https://vnexpress.net/nhung-su-vang-mat-gay-tiec-nuoi-o-qua-bong-vang-4924163.html",
      "summary": "Trong danh sách 30 ứng viên cho danh hiệu Quả Bóng Vàng 2025 được tạp chí France Football công bố tối 7/8 thiếu vắng một số nhà vô địch châu Âu, những trụ cột hay các tài năng tấn công sáng giá của các đội bóng lớn.",
      "source": "VnExpress - Thể Thao",
      "category": "Thể thao",
      "published": "2025-08-08T02:31:20+07:00",
      "fetched": "2025-08-09T09:26:55.406697+07:00"
    },
    {
      "id": "7adc6a689a26aebd4a257d6b82fe5691",
      "title": "Nhà sáng lập Zalo: Chấp nhận chỉ trích để giữ giá trị cốt lõi",
      "link": "https://vnexpress.net/nha-sang-lap-zalo-chap-nhan-chi-trich-de-giu-gia-tri-cot-loi-4924176.html",
      "summary": "Tự coi mình là \"người dùng số 0\" khó tính nhất, Vương Quang Khải đứng sau các tính năng của Zalo suốt 13 năm, chấp nhận những lời chỉ trích để theo đuổi giá trị cốt lõi cho sản phẩm.",
      "source": "VnExpress - Công Nghệ",
      "category": "Công nghệ",
      "published": "2025-08-08T02:01:49+07:00",
      "fetched": "2025-08-09T09:26:54.403822+07:00"
    },
    {
      "id": "d6ec684fe99c6c13d2bb86c7d0266295",
      "title": "Meta cho chuyển khoản trong Messenger tại Việt Nam",
      "link": "https://vnexpress.net/meta-cho-chuyen-khoan-trong-messenger-tai-viet-nam-4924104.html",
      "summary": "Người dùng Messenger trong nước có thể trao đổi thông tin, mua bán, sau đó kích hoạt thanh toán với ngân hàng hoặc ví điện tử đã liên kết.",
      "source": "VnExpress - Công Nghệ",
      "category": "Công nghệ",
      "published": "2025-08-08T02:00:00+07:00",
      "fetched": "2025-08-09T09:26:54.404442+07:00"
    },
    {
      "id": "b73ef4d96e5e51769dd444d0b0b6d451",
      "title": "Nvidia: Tạo cửa hậu GPU làm rạn nứt niềm tin công nghệ Mỹ",
      "link": "https://vnexpress.net/nvidia-tao-cua-hau-gpu-lam-ran-nut-niem-tin-cong-nghe-my-4924114.html",
      "summary": "Nvidia cho biết các chính phủ không nên ép doanh nghiệp theo dõi khách hàng bằng cửa hậu trong sản phẩm, điều Mỹ đang đề xuất với công ty.",
      "source": "VnExpress - Công Nghệ",
      "category": "Công nghệ",
      "published": "2025-08-08T01:00:00+07:00",
      "fetched": "2025-08-09T09:26:54.404612+07:00"
    },
    {
      "id": "d6de7cbea7a780c8a6f13a12de0c6752",
      "title": "Chuyện gì xảy ra nếu Ấn Độ, Trung Quốc ngừng mua dầu Nga",
      "link": "https://vnexpress.net/chuyen-gi-xay-ra-neu-an-do-trung-quoc-ngung-mua-dau-nga-4923861.html",
      "summary": "Nếu dòng chảy dầu Nga gián đoạn, Ấn Độ có thể tốn 11 tỷ USD mỗi năm, Moskva chịu thêm sức ép ngân sách và lạm phát toàn cầu sẽ tăng vọt.",
      "source": "VnExpress - Kinh Doanh",
      "category": "Kinh doanh",
      "published": "2025-08-08T00:00:00+07:00",
      "fetched": "2025-08-09T09:26:51.091169+07:00"
    },
    {
      "id": "48d7cb8e447a7e330476c1eb2d6cf2be",
      "title": "Nơi 'tụ họp' của robot thông minh tại Trung Quốc",
      "link": "https://vnexpress.net/noi-tu-hop-cua-robot-thong-minh-tai-trung-quoc-4923967.html",
      "summary": "Cửa hàng Robot Mall tại Bắc Kinh trưng bày và bán hơn 100 robot từ khoảng 40 nhà sản xuất Trung Quốc.",
      "source": "VnExpress - Công Nghệ",
      "category": "Công nghệ",
      "published": "2025-08-08T00:00:00+07:00",
      "fetched": "2025-08-09T09:26:54.404766+07:00"
    },
    {
      "id": "d03a81c0147551229ed6ccd552e7f1bd",
      "title": "Người chơi trung thành 'lung lay' khi giá Pi lập đáy mới",
      "link": "https://vnexpress.net/nguoi-choi-trung-thanh-lung-lay-khi-gia-pi-lap-day-moi-4923494.html",
      "summary": "Một số người từng tin tưởng \"tuyệt đối\" dự án Pi Network nhưng bắt đầu cân nhắc bán token khi giá tiền ảo lập đáy 0,34 USD.",
      "source": "VnExpress - Công Nghệ",
      "category": "Công nghệ",
      "published": "2025-08-07T22:00:00+07:00",
      "fetched": "2025-08-09T09:26:54.404924+07:00"
    }
  ]
};